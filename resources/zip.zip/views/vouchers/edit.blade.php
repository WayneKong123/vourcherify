

@extends('layouts.app')

@section('title', 'Edit Voucher')

@section('content')
    <h1>Edit Voucher</h1>
    <form method="POST" action="{{ route('vouchers.update', [$voucher]) }}">




        @csrf
        @method('PUT')

        
        <label for="voucher_type">Voucher Type:</label>
        <select name="voucher_type" id="voucher_type">
            <option value="discount" {{ $voucher->voucher_type === 'discount' ? 'selected' : '' }}>Discount</option>
            <option value="gift_card" {{ $voucher->voucher_type === 'gift_card' ? 'selected' : '' }}>Gift Card</option>
            <option value="loyalty_card" {{ $voucher->voucher_type === 'loyalty_card' ? 'selected' : '' }}>Loyalty Card</option>
        </select>
        <br>
        <label for="discount_amount">Discount Amount:</label>
        <input type="number" name="discount_amount" id="discount_amount" value="{{ $voucher->discount_amount }}">
        <br>
        <label for="expiration_date">Expiration Date:</label>
        <input type="date" name="expiration_date" id="expiration_date" value="{{ $voucher->expiration_date }}">
        <br>
        <label for="customer_id">Customer ID:</label>
        <input type="number" name="customer_id" id="customer_id" value="{{ $voucher->customer_id }}">
        <br>
        <label for="product_id">Product ID:</label>
        <input type="number" name="product_id" id="product_id" value="{{ $voucher->product_id }}">
        <br>
        <button type="submit">Update Voucher</button>
    </form>
@endsection
