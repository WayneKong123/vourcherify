@extends('layouts.app')

@section('title', 'Vouchers')

@section('content')
    <h1>Vouchers</h1>

    <p><a href="{{ route('vouchers.create') }}">Create New Voucher</a></p>




    @if ($vouchers->isEmpty())
        <p>No vouchers found.</p>
    @else
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Expiration Date</th>
                    <th>Discount Amount</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($vouchers as $voucher)
                    <tr>
                        <td>{{ $voucher->id }}</td>
                        <td>{{ $voucher->VoucherCode }}</td>
                        <td>{{ $voucher->ExpirationDate }}</td>
                        <td>{{ $voucher->DiscountAmount }}</td>
                        <td>
                            <a href="{{ route('vouchers.show', $voucher) }}">View</a>
                            <a href="{{ route('vouchers.edit', $voucher) }}">Edit</a>
                            <form method="POST" action="{{ route('vouchers.destroy', $voucher) }}">
                                @csrf
                                @method('DELETE')
                                <button type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
@endsection
