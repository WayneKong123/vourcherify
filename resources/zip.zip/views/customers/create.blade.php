@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Create Customer</h1>
        <form method="POST" action="{{ route('customers.store') }}">
    @csrf
    <div>
        <label for="FirstName">First Name:</label>
        <input type="text" name="FirstName" value="{{ old('FirstName') }}">
        @error('FirstName')
            <span class="error">{{ $message }}</span>
        @enderror
    </div>
    <div>
        <label for="LastName">Last Name:</label>
        <input type="text" name="LastName" value="{{ old('LastName') }}">
        @error('LastName')
            <span class="error">{{ $message }}</span>
        @enderror
    </div>
    <div>
        <label for="Email">Email:</label>
        <input type="email" name="Email" value="{{ old('Email') }}">
        @error('Email')
            <span class="error">{{ $message }}</span>
        @enderror
    </div>
    <div>
        <label for="PhoneNumber">Phone Number:</label>
        <input type="text" name="PhoneNumber" value="{{ old('PhoneNumber') }}">
        @error('PhoneNumber')
            <span class="error">{{ $message }}</span>
        @enderror
    </div>
    <div>
        <label for="Address">Address:</label>
        <input type="text" name="Address" value="{{ old('Address') }}">
        @error('Address')
            <span class="error">{{ $message }}</span>
        @enderror
    </div>
    <div>
        <button type="submit">Submit</button>
    </div>
</form>

@if ($errors->any())
    <div class="error">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
    
    </div>
@endsection
